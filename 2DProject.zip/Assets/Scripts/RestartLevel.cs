﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class RestartLevel : MonoBehaviour
{

    static public int Scene = SceneManager.GetActiveScene().buildIndex;

    private void Next()
    {
        {
            SceneManager.LoadScene(Scene++);
        }
    }

    static public void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
